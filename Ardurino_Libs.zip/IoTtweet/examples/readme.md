Example of IoTtweet library using
Have fun :)
IoTtweet Team
